// *** main_task3.java ***
package task3;

public class main_task3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("[201812767 이지훈]\n");
		
		engWordTest jhlee = new engWordTest("이지훈");
		jhlee.makeVoc("quiz.txt");
		
	}

}
