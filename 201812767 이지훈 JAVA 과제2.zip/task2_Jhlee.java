package task2;

import java.util.Scanner;

public class task2_Jhlee {

	public static Scanner s = new Scanner(System.in);

	// 주차장 크기의 행, 열 final integer 선언
	static final int ROW = 4;
	static final int COL = 3;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// 0) 학번이름 출력
		System.out.print("[201812767 이지훈 JAVA 과제2]\n");

		// 1) 주차 차량 정보 배열 생성
		String[][] parkingSpace = new String[ROW][COL];

		// 추가적인 주차 여부 정보 배열 생성
		boolean[][] isOn = new boolean[ROW][COL];

		int sel = 0;

		// 2) 메뉴 운영하기
		while (sel != 4) {

			sel = showMenu(isOn);

			switch (sel) {
			case 1: { // 주차하기 메뉴
				parking(parkingSpace, isOn);
				break;
			}
			case 2: { // 차량검색 메뉴
				searchCar(parkingSpace);
				break;
			}
			case 3: { // 출차하기 메뉴
				exitCar(parkingSpace, isOn);
				break;
			}
			case 4: { // 종료 메뉴
				System.out.print("\n프로그램을 종료합니다.\n");
				break;
			}
			default: { // 기타
				break;
			}
			} // end of switch(sel)
		}
	}

	private static void exitCar(String[][] parkingSpace, boolean[][] isOn) {
		// TODO Auto-generated method stub

		// 출차할 차량 번호 저장 변수 및 출차 여부 변수 선언
		String ss;
		boolean isExited = false;

		System.out.print("\n**** 출차하기 ****");
		System.out.print("\n출차할 차량 번호를 입력해주세요 : ");
		ss = s.next();

		// 5-A) 출차할 차량이 있을 경우 출차하고 해당 공간 빈공간
		for (int i = 0; i < ROW; i++) {
			for (int j = 0; j < COL; j++) {
				if (ss.equals(parkingSpace[i][j])) {
					parkingSpace[i][j] = null;
					isOn[i][j] = false;
					isExited = true;
					System.out.printf("%s 차량이 출차되었습니다. 안녕히 가세요.\n", ss);
				}
			}
		}

		if (!isExited)
			System.out.print("차량이 존재하지 않습니다. 차량번호 확인 후 처음부터 다시 진행해주세요.\n");

	}

	private static void searchCar(String[][] arr) {
		// TODO Auto-generated method stub

		// 입력받은 문자열 저장 변수 선언 및 조회 결과 T/F 저장 변수 선언
		String ss;
		boolean isFounded = false;
		System.out.print("\n**** 차량 검색 ****");
		System.out.print("\n조회할 차량 번호를 입력해주세요 : ");
		ss = s.next();

		// 4-A) 차량이 주차되어 있는 경우, 차량의 위치 출력
		for (int i = 0; i < ROW; i++) {
			for (int j = 0; j < COL; j++) {
				if (ss.equals(arr[i][j])) {
					System.out.printf("%s는 (%d, %d)에 위치합니다.\n", ss, i + 1, j + 1);
					isFounded = true;
				}
			}
		}

		// 4-B) 차량이 없는 경우
		if (!isFounded)
			System.out.print("해당 차량이 존재하지 않습니다. 차량번호 확인 후 처음부터 다시 진행해 주세요.\n");
	}

	private static void parking(String[][] parkingSpace, boolean[][] isOn) {
		// TODO Auto-generated method stub
		int row = -1, col = -1;

		// 3-A) 주차 정보 입력 받기
		System.out.print("\n**** 주차하기 ****");
		System.out.print("\n주차할 위치를 선택해주세요 : ");
		row = s.nextInt();
		col = s.nextInt();

		// 3-C,D) 차량 위치 over bound 및 중복 제외 예외처리
		if (row < 1 || row > 4 || col < 1 || col > 3) {
			System.out.print("위치 번호를 확인해주세요. 처음부터 다시 시작해주세요.\n");
			return;
		} else if (isOn[row - 1][col - 1] == true) {
			System.out.print("다른 차량이 주차되어 있습니다. 처음부터 다시 시작해주세요.\n");
			return;
		}

		String ss, sss; // ss:차량번호 임시저장, sss:sel입력인자
		System.out.print("차량 번호를 입력해주세요 : ");
		ss = s.next();

		System.out.printf("차량 번호 %s 맞습니까? (y/n) : ", ss);
		sss = s.next();
		char sel = sss.charAt(0);

		// 3-A) 차량 주차하기
		if (sel == 'y') {
			// 주차하는 코드
			parkingSpace[row - 1][col - 1] = ss;
			isOn[row - 1][col - 1] = true;
			System.out.printf("%s 차량의 주차를 완료하였습니다.\n", ss);
		}
		// 3-E) 차량 번호 확인 : n
		else if (sel == 'n') {
			System.out.print("처음부터 다시 진행해주세요.\n");
		} else {
			System.out.print("입력 값이 잘못되었습니다. 처음부터 다시 진행해주세요.\n");
		}

		return;
	}

	private static int showMenu(boolean[][] arr) {
		int sel = 0;

		// 2-D) 메뉴 화면 반복적으로 출력하기, 종료는 main함수에 branch로 구현
		while (true) {

			System.out.print("\n**** 주차 현황 ****\n");
			System.out.print("  1 2 3");

			// 2-A) 주차 공간 이용가능 여부 출력
			for (int i = 0; i < ROW; i++) {
				System.out.printf("\n%d", i + 1);
				for (int j = 0; j < COL; j++) {
					System.out.printf("%2c", arr[i][j] ? '♥' : '♡');
				}
			}

			// 2-B) 4가지 메뉴 구성하기
			System.out.print("\n\n1) 주차하기 2) 차량검색 3) 출차하기 4) 종료" + "\n- 메뉴를 선택하세요 : ");

			sel = s.nextInt();

			// 2-C) 메뉴에 없는 번호 선택 시 예외처리
			if (!(sel > 0 && sel < 5)) {
				System.out.print("\n메뉴 번호를 확인 후 다시 입력해 주세요\n");
				continue;
			} else
				break;
		}
		return sel;
	}

}
