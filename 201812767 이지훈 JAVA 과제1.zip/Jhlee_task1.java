package task1;

import java.io.IOException;
import java.util.Scanner;

public class Jhlee_task1 {

	public static void main(String[] args) throws IOException{
		// TODO Auto-generated method stub
		System.out.println("[201812767 이지훈]\n");
		
		int sel = -1;
		Scanner s = new Scanner(System.in);
		
		while(!(sel==4)) {
			sel = -1;
			System.out.println("=== < M E N U > ==========================================");
			System.out.println("1) 쿠폰으로 초콜릿 구매하기  2) 문자 산수 퍼즐  3) 구구단 출력하기  4) 종료");
			System.out.printf("  - 메뉴를 선택하세요 : ");
			sel=s.nextInt();
			
			switch (sel) {
			
			case 1:{ // 쿠폰으로 초콜릿 구매
				System.out.printf("\n* 문제1) 쿠폰으로 초콜릿 구매하기\n돈을 넣어주세요 : ");
				
				final int RATE = 7;
				int choco, coupon=0, add = 0;
				// add : 추가로 얻은 초콜릿의 개수
				
				choco = s.nextInt();
				coupon = choco;
				
				// 쿠폰 7개로 초콜릿을 살 수 있을 때의 process
				while(coupon >= RATE) { 
					add = coupon / RATE;
					choco += add;
					coupon = coupon + (1-RATE)*add;
				}
				
				System.out.printf("=> 초콜릿 %d개, 쿠폰 %d개\n\n", choco, coupon);
				break;
			}
			case 2:{ // 문자 산수 퍼즐
				System.out.printf("\n* 문제2) 문자 산수 퍼즐 문제\n");
				
				// TOO + TOO + TOO + TOO = GOOD
				// 400*T==1000*G+66*O+D
				// 0<T, 0<G<4
				
				int T, O, G, D, method=0;	
				
				for(T=1;T<10;T++) {
					for(O=0;O<10;O++) {
						for(G=1;G<4;G++) {
							for(D=0;D<10;D++){
								if(400*T==1000*G+66*O+D) {
									System.out.printf(" '[해답%d] T=%d, O=%d, G=%d, D=%d 입니다.\n", method+1, T, O, G, D);
									method++;
								}
							}
						}
					}
				}
				System.out.printf("\n");
				break;
			}
			case 3:{ // 구구단 출력하기 
				int n = 0, count = 0;
				
				// 단 수 입력 예외처리
				while(!(n>0&&n<9)) {
					System.out.printf("\n* 문제3) 구구단 출력하기\n출력 단수 : ");
					n=s.nextInt();
					if(!(n>0 && n<9)) {
						System.out.println("출력 단수 입력을 확인해주세요.");
						continue;
					}
				}
				
				// count => n단의 출력이 몇 번인 지
				count=8/n+1;
				
				for(int c=0;c<count;c++) {
					for(int i=1;i<10;i++) {
						for(int j=2+n*c;j<n+2+n*c;j++) {
							if(j==10) // 9단 초과 예외처리
								break;
							System.out.printf("%d *%2d =%3d\t",j,i,j*i);
						}
						System.out.printf("\n");
					}
					System.out.printf("\n");
				}
				break;
			}
			case 4:{	// 종료
				System.out.println("프로그램을 종료합니다.\n");
				break;
			}
			default:{
				System.out.println("다시 입력해주세요.\n");
				break;
			}
			}	// end of switch
		} 		// end of while()
	} 			// end of main
} 				// end of class